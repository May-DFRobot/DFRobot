/*!
 * @file screenInteractiveEye.ino
 * @brief This document mainly realizes the interactive display function of a 3.5-inch screen combined with a laser matrix distance sensor
 * @copyright	Copyright (c) 2025 DFRobot Co.Ltd (http://www.dfrobot.com)
 * @license The MIT License (MIT)
 * @author [jiali](zhixinliu@dfrobot.com)
 * @version V1.0
 * @date 2025-09-22
 * @url https://www.dfrobot.com.cn/goods-4167.html
 */
#include "Arduino.h"
#include "DFRobot_GDL.h"
#include "DFRobot_matrixLidarDistanceSensor.h"
#include "figure.h"

#define TFT_DC    8    
#define TFT_CS    27      
#define TFT_RST   26     
#define TFT_BL    15   

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))

 DFRobot_ST7365P_320x480_HW_SPI display(/*dc=*/TFT_DC,/*cs=*/TFT_CS,/*rst=*/TFT_RST,/*bl=*/TFT_BL);
 DFRobot_matrixLidarDistanceSensor tof(0x33);

#define EYE_SOCKET_WIDE 49               //The width of the eye frame photo
#define EYE_SOCKET_LONG 43               //The length of the eye frame photo
#define EYE_MID_POS_X   24               //The coordinate x of the midpoint of the eyeball on the orbital canvas
#define EYE_MID_POS_Y   21               //The coordinate y of the midpoint of the eyeball on the orbital canvas
#define LEFT_EYE_COORDINATE_X 81         //The coordinate x of the left eye frame on the canvas
#define LEFT_EYE_COORDINATE_Y 188        //The coordinate y of the left eye frame on the canvas
#define RIGHT_EYE_COORDINATE_X 194       //The coordinate x of the right eye frame on the canvas
#define RIGHT_EYE_COORDINATE_Y 188       //The coordinate y of the right eye frame on the canvas

const uint8_t eyebrowWide = 185,eyebrowLong = 21;   //The size of the eyebrow photo
const uint8_t eyebrowX = 72,eyebrowY = 152;        //The coordinates of the eyebrow photo on the canvas
const uint8_t eyeWide1 = 54,eyeLong1 = 54;        //The size of the eye socket photo
const uint8_t eyeLeftX = 77,eyeLeftY = 180;       //The coordinates of the photo of the left eye on the canvas
const uint8_t eyeRight_x = 192,eyeRight_y = 180;  //The coordinates of the photo of the right eye on the canvas

// Eye condition
uint8_t eyeStates = 4;//0-- open eyes state 1-- closed eyes state 2-- During the blinking process

int eyeWide = 27;// The size of the eye photo
int eyeLong = 35;
int baseEye_x  = EYE_MID_POS_X;
int baseEye_y = EYE_MID_POS_Y;
uint8_t oldEye_l[35][27] = {0};
uint8_t oldEye_r[35][27] = {0};
uint8_t first_erasure = 0;

int baseMoveEyeLeft_x  = 28;//The coordinates of the midpoint of the left eye on the canvas
int baseMoveEyeLeft_y = 22;
int baseMoveEyeRight_x  = 19;// The coordinates of the midpoint of the right eye on the canvas
int baseMoveEyeRight_y = 22;

uint64_t newTime;
uint64_t oldTime;

// Coordinate range
const uint8_t X_MIN = 5;
const uint8_t X_MAX = 43;
const uint8_t Y_MIN = 10;
const uint8_t Y_MAX = 37;

uint8_t targetX = 0,targetY = 0;

int32_t focusX = -255;
int32_t  focusY = -255;
int32_t randomFocusX = 255,randomFocusY = 255;
int32_t minThld = 1500;

uint8_t interactFlag  = 0;
uint8_t oldInteractFlag = 0;
uint8_t blinkFlag = 0;

uint64_t end_time;
uint64_t start_time;


/*
  This program implements an interactive eye display system based on a 3.5-inch screen and a laser matrix distance sensor.
  Its main function is to detect the user's position through the laser sensor, and control the pair of virtual eyes on 
  the screen to perform real-time tracking and expression changes: when the user approaches, the eyes will gaze at the
  user; when the user moves away, they will blink; when the user is too close, they will close their eyes; it can also 
  achieve smooth eye movement and natural blinking animation effects; creating a vivid human-computer interaction experience.
*/
void setup()
{
  Serial.begin(115200);
  display.begin();
  display.setRotation(0);

  display.drawPIC(0,0,320 ,480,(uint8_t *)figure);

  sensorModuleInit();
  
  oldTime = millis();
}

void loop()
{
  interactFlag = coordinatop(0);

  if(interactFlag == 0 && oldInteractFlag != 0){
    eyeStates = 1;
  }else if(interactFlag == 1){
    eyeStates = 4;
  }else if(interactFlag == 2 && oldInteractFlag != 2){
    eyeStates = 2;
    blinkFlag = 1;
  }

  oldInteractFlag = interactFlag;

  newTime = millis();
  if(newTime -oldTime >= 3000){

    if(blinkFlag == 0 && eyeStates == 2){
      blinkFlag = 1;
    }
    oldTime = newTime;
  }
  eyeInteraction();
}

void sensorModuleInit(){  // Initialization of Laser Distance Sensor
  while(tof.begin() != 0){
    Serial.println("begin error !!!!!");
  }
  Serial.println("begin success");

  while(tof.getAllDataConfig(eMatrix_8X8) != 0){
    Serial.println("init error !!!!!");
    delay(1000);
  }
  Serial.println("init success");

  // for(int i = 0;i<2;i++){
  //   minThld = 5000;
  //   interactFlag = coordinatop(1);
  //   delay(10);
  // }
  onBaseDraweye(1);
  eyeWhiteRefresh();
}

uint8_t coordinatop(uint8_t initMode)// Distance measurement data processing function
{
  uint16_t buf[64];
  int32_t minDate = minThld;
  int32_t temp;
  focusX = 255;
  focusY = 255;

  uint8_t flag[4] = {0};

  tof.getAllData(buf);
  for(int i = 0;i < 8;i++){
    for(int j = 0;j<8;j++){
      if(initMode){
        
        if(minThld > buf[(i*8)+j]){
          minThld = buf[(i*8)+j];
        }
      }else{
          // Serial.print(buf[(i*8)+j]);
          // Serial.print("\t");
          if(buf[(i*8)+j]<30){
              flag[0] = 1;
          }
          if(buf[(i*8)+j] > minThld){
            flag[2] = 1;
          }
          if(minDate >= buf[(i*8)+j]){
            minDate = buf[(i*8)+j];
            focusX = j + 1;
            focusY = i + 1;
            flag[1] = 1;
          }
        
      }
    }
  //  Serial.println();
  }
//  Serial.println("______________________________");
  for(int i = 2;i >= 0;i--){
    if(flag[i] == 1){
      flag[3] = i;
    }
  }
  
  if(initMode){
    minThld = minThld - 30;
    if(minThld > 1330){
      minThld  = 1300;
    }
  }

  return flag[3];
}


//限幅
void positionLimitation(uint8_t *x,uint8_t *y) // Limit the range of eye movement
{
  MIN(*x,X_MIN);
  MAX(*x,X_MAX);
  MIN(*y,Y_MIN);
  MAX(*y,Y_MAX);
}


uint8_t V[5] = {7, 5, 3, 2, 1}; // Speed array (step value)

// Smooth eye movement function
void eyeSmoothMotion(uint8_t targetX, uint8_t targetY) {
    static uint8_t oldTargetX = 255, oldTargetY = 255; 
    static bool isMovingX = false, isMovingY = false; 
    if (oldTargetX != targetX) {
        oldTargetX = targetX;
        isMovingX = true; 
    }
    if (oldTargetY != targetY) {
        oldTargetY = targetY;
        isMovingY = true;
    }
    int diffX = targetX - baseEye_x;
    int diffY = targetY - baseEye_y;
    
    uint8_t absDiffX = abs(diffX);
    uint8_t absDiffY = abs(diffY);
    if (isMovingX) {
        uint8_t vIndexX;
        if (absDiffX > 20) {
            vIndexX = 0; 
        } else if (absDiffX > 15) {
            vIndexX = 1; 
        } else if (absDiffX > 5) {
            vIndexX = 2; 
        } else if (absDiffX > 2) {
            vIndexX = 3; 
        } else {
            vIndexX = 4; 
        }
        uint8_t speedStepX = V[vIndexX];
        if (absDiffX <= speedStepX) {
            baseEye_x = targetX;
            isMovingX = false;
        } else {
            if (diffX > 0) {
                baseEye_x += speedStepX;
            }else {
                baseEye_x -= speedStepX;
            }
        }
    }
    if (isMovingY) {
        uint8_t vIndexY;
        if (absDiffY > 20) {
            vIndexY = 0; 
        } else if (absDiffY > 15) {
            vIndexY = 1; 
        } else if (absDiffY > 5) {
            vIndexY = 2; 
        } else if (absDiffY > 2) {
            vIndexY = 3; 
        } else {
            vIndexY = 4; 
        }
        
        uint8_t speedStepY = V[vIndexY];
        if (absDiffY <= speedStepY) {
            baseEye_y = targetY;
            isMovingY = false;
        } else {
            if (diffY > 0) {
                baseEye_y += speedStepY;
            } else {
                baseEye_y -= speedStepY;
            }
        }
    }
}

void eyeWhiteRefresh(void)// Refresh the white area of the eye socket
{
  display.drawPIC(LEFT_EYE_COORDINATE_X,LEFT_EYE_COORDINATE_Y,EYE_SOCKET_WIDE ,EYE_SOCKET_LONG,(uint8_t*)base_l);
  display.drawPIC(RIGHT_EYE_COORDINATE_X,RIGHT_EYE_COORDINATE_Y,EYE_SOCKET_WIDE ,EYE_SOCKET_LONG,(uint8_t*)base_r);
}

void onBaseDraweye(uint8_t initPlace)// Draw eyes on the upper part of the eye socket
{
  int drawEyeLeft_x,drawEyeRight_x;
  int drawEyeLeft_y,drawEyeRight_y;

  int drawEye_x,drawEye_y;

  if(initPlace == 0){
    drawEye_x = baseEye_x - eyeWide / 2;//The coordinate of the eye photo on the upper left corner of the canvas
    drawEye_y = baseEye_y - eyeLong / 2;

    drawEyeLeft_x = drawEye_x;
    drawEyeLeft_y = drawEye_y;
    drawEyeRight_x = drawEye_x;
    drawEyeRight_y = drawEye_y;

  }else{
    drawEye_x = baseMoveEyeLeft_x - eyeWide / 2;
    drawEye_y = baseMoveEyeLeft_y - eyeLong / 2;

    drawEyeLeft_x = drawEye_x;
    drawEyeLeft_y = drawEye_y;

    drawEye_x = baseMoveEyeRight_x - eyeWide / 2;
    drawEye_y = baseMoveEyeRight_y - eyeLong / 2;

    drawEyeRight_x = drawEye_x;
    drawEyeRight_y = drawEye_y;

  }


  static int oldDrawEye_L_x = drawEye_x;
  static int oldDrawEye_L_y = drawEye_y;// Save the old coordinate points
  
  static int oldDrawEye_R_x;
  static int oldDrawEye_R_y;

  if(first_erasure == 0){
    first_erasure = 1;
  }else{
    erasePaint(oldDrawEye_L_x,oldDrawEye_L_y,0,base_l,oldEye_l);
    erasePaint(oldDrawEye_R_x,oldDrawEye_R_y,0,base_r,oldEye_r);
  }
    erasePaint(drawEyeLeft_x,drawEyeLeft_y,1,base_l,oldEye_l);
    erasePaint(drawEyeRight_x,drawEyeRight_y,1,base_r,oldEye_r);
    oldDrawEye_L_x = drawEyeLeft_x;
    oldDrawEye_L_y = drawEyeLeft_y;
    oldDrawEye_R_x = drawEyeRight_x;
    oldDrawEye_R_y = drawEyeRight_y;

}

void erasePaint(int draweye_x,int draweye_y,uint8_t erasureFlag,uint16_t base[43][49],uint8_t oldEye[35][27])// Remove the eyes from the eye socket
{
int itemp,jtemp;

  for(int i = 0;i < eyeLong;i++){
    itemp = draweye_y + i;
    if(itemp < 0 || itemp >= EYE_SOCKET_LONG){
      continue;
    }
    for(int j  = 0;j < eyeWide;j++){
      jtemp = draweye_x + j;
      if(jtemp < 0 || jtemp >= EYE_SOCKET_WIDE)
        continue;
      if(erasureFlag){
        if(base[itemp][jtemp] == 0xEF1B){
          oldEye[i][j] = 1;
          base[itemp][jtemp] = eye[i][j]; 
        }
      }else{
        if(oldEye[i][j] == 1){
          base[itemp][jtemp] = 0xEF1B;
          oldEye[i][j] = 0;
        }
      }
    }
  }
}


void eyeInteraction()// Eye Interaction Function
{
  static uint8_t blinkingCount = 0;
  static uint8_t eyeTrackFlag = 0;
  static uint8_t eyeStates_ = eyeStates;

  switch(eyeStates_)// 0 - Opened eyes state  1 - Closed eyes state  2 - In the process of closing eyes  3 - In the process of opening eyes
  {
    case 0:
      blinkingCount = 0;
      if(eyeStates_ != eyeStates){
          eyeStates_ = 5;
      }
      break;
    case 1:// Close your eyes
      if(blinkingCount < 2){
        blinkingCount+=1;
      }
      if(eyeStates_ != eyeStates){
        eyeStates_ = 3;
      }

      break;
    case 2://During the process of closing one's eyes, there is a transition to opening them.
      if(blinkFlag){
        if(++blinkingCount >= 2){
          eyeStates_ = 3;
        }
      }else{
        blinkingCount = 0;
      }
      if(eyeStates_ != eyeStates && blinkFlag == 0){
          eyeStates_ = 5;
        }
      break;
    case 3:
      if(--blinkingCount <= 0){
        eyeStates_ = 0;
        blinkFlag = 0;
      }
      break;
    case 4:// Eye tracking scan
      if(eyeTrackFlag){// Make sure your eyes are open before starting.
        eyeballRefresh();
      }else{
        eyeRefresh(0);
        eyeTrackFlag = 1;
      }
      if(eyeStates_ != eyeStates){
        eyeStates_ = 5;
        eyeTrackFlag = 0;

      }
      break;
    case 5:// Converter

      if(eyeStates_ != eyeStates){

        eyeStates_ = eyeStates;
        blinkingCount = 0;
      }

      break;
  }

  if(eyeStates_ <= 3 && eyeStates_ >= 0 || eyeStates_ == 5){
    eyeRefresh(blinkingCount);
  }
}

void eyeballRefresh(void)// Eye-tracking function
{
  if(interactFlag == 4){
      targetX = EYE_MID_POS_X;
      targetY = EYE_MID_POS_Y;
  }else{
    targetX = map(focusX,0,7,X_MAX, X_MIN);
    targetY = map(focusY,0,7,Y_MIN, Y_MAX);
    positionLimitation(&targetX,&targetY);
  }
  eyeSmoothMotion(targetX,targetY);
  onBaseDraweye(0);
  eyeWhiteRefresh();
}

void eyeRefresh(uint8_t blink)//Eye Refresh Function
{
  switch(blink)
    {
      case 0:
        display.drawPIC(eyeLeftX,eyeLeftY,eyeWide1 ,eyeLong1,(uint8_t*)eye_l_0);
        display.drawPIC(eyeRight_x,eyeRight_y,eyeWide1 ,eyeLong1,(uint8_t*)eye_r_0);
        display.drawPIC(eyebrowX,eyebrowY,eyebrowWide ,eyebrowLong,(uint8_t*)eyebrow_0);
        break;
      case 1:
        display.drawPIC(eyeRight_x,eyeRight_y,eyeWide1 ,eyeLong1,(uint8_t*)eye_r_2);
        display.drawPIC(eyeLeftX,eyeLeftY,eyeWide1 ,eyeLong1,(uint8_t*)eye_l_2);
        display.drawPIC(eyebrowX,eyebrowY,eyebrowWide ,eyebrowLong,(uint8_t*)eyebrow_3);
        break;
      case 2:
        //display.drawPIC(eyebrowX,eyebrowY,eyebrowWide ,eyebrowLong,(uint8_t*)eyebrow_3);
        display.drawPIC(eyeLeftX,eyeLeftY,eyeWide1 ,eyeLong1,(uint8_t*)eye_l_3);
        display.drawPIC(eyeRight_x,eyeRight_y,eyeWide1 ,eyeLong1,(uint8_t*)eye_r_3);
        break;
    }  
}
