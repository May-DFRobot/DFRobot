Maixduino
========

Arduino core for Maix Board (K210)


## Docs

Docs: [maixduino.sipeed.com](https://maixduino.sipeed.com/)

## Install

Refer install doc: [Install](https://maixduino.sipeed.com/en/get_started/install.html)


## Other SDK

If you want to code by scripts, refer to our [MaixPy](https://maixpy.sipeed.com)




